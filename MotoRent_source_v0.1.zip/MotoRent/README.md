# MotoRent — MVP 0.1

Aplicación Android nativa en Kotlin + Jetpack Compose.

## Incluye
- Interfaz oscura.
- Calculadora manual de ofertas.
- Filtro de COP por kilómetro y distancia de recogida.
- Estimación configurable de gasolina por kilómetro.
- OCR de capturas elegidas por el usuario mediante ML Kit.
- No se conecta a inDrive, no usa accesibilidad y no acepta/rechaza viajes.

## Abrir el proyecto
1. Instala Android Studio.
2. Descomprime el proyecto.
3. Abre la carpeta `MotoRent` desde Android Studio.
4. Deja que Gradle sincronice las dependencias.
5. Conecta tu teléfono Android con depuración USB activada o usa un emulador.
6. Pulsa Run.

Requisitos: Android Studio reciente, JDK 17 y Android SDK 35.

## Limitaciones de esta versión
El OCR solo analiza una imagen/captura que el usuario selecciona. No lee la pantalla en vivo de inDrive. El OCR puede confundir cifras; siempre verifica y corrige los datos antes de usar el resultado.

La cifra de gasolina por kilómetro es un parámetro editable y debe calibrarse con el consumo real de la moto y el precio del combustible. La estimación no incluye automáticamente mantenimiento, llantas, aceite, depreciación, tráfico ni tiempos de espera.

## Próximas etapas
- Guardar configuración e historial local.
- Mejorar reconocimiento de precio/distancia con plantillas revisadas.
- Evaluar captura de pantalla en vivo con consentimiento explícito de Android y revisión de términos de inDrive. Sin pulsaciones automáticas.
