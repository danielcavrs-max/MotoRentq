package com.motorent.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.NumberFormat
import java.util.Locale

private val Bg = Color(0xFF0B1016)
private val Panel = Color(0xFF151E28)
private val Accent = Color(0xFF45D483)
private val Muted = Color(0xFF9BA9B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MotoRentApp() }
    }
}

@Composable
fun MotoRentApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White,
            secondary = Color(0xFF6CB6FF)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Dashboard()
        }
    }
}

@Composable
private fun Dashboard() {
    val context = LocalContext.current
    var fare by remember { mutableStateOf("12000") }
    var tripKm by remember { mutableStateOf("5") }
    var pickupKm by remember { mutableStateOf("1") }
    var minimumPerKm by remember { mutableStateOf("1500") }
    var maxPickup by remember { mutableStateOf("3") }
    var fuelCostPerKm by remember { mutableStateOf("220") }
    var ocrText by remember { mutableStateOf("Aún no has analizado una captura.") }
    var status by remember { mutableStateOf("Completa los datos o analiza una captura.") }
    var isReading by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            isReading = true
            try {
                val image = InputImage.fromFilePath(context, uri)
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text
                        // OCR is advisory only. The user reviews and enters values manually.
                        val priceMatch = Regex("""(?:\$|COP\s*)\s*([\d.,]{4,})""", RegexOption.IGNORE_CASE)
                            .find(result.text)
                        priceMatch?.groupValues?.getOrNull(1)?.let { raw ->
                            val digits = raw.filter { it.isDigit() }
                            if (digits.length in 4..8) fare = digits
                        }
                        status = "Lectura terminada. Revisa el texto y confirma los datos."
                        isReading = false
                        recognizer.close()
                    }
                    .addOnFailureListener {
                        status = "No se pudo leer la imagen. Puedes ingresar los datos manualmente."
                        isReading = false
                        recognizer.close()
                    }
            } catch (_: Exception) {
                status = "No se pudo abrir la imagen. Intenta con otra captura."
                isReading = false
            }
        }
    }

    val fareN = fare.toDoubleOrNull() ?: 0.0
    val tripN = tripKm.toDoubleOrNull() ?: 0.0
    val pickupN = pickupKm.toDoubleOrNull() ?: 0.0
    val minN = minimumPerKm.toDoubleOrNull() ?: 0.0
    val maxPickupN = maxPickup.toDoubleOrNull() ?: 0.0
    val fuelN = fuelCostPerKm.toDoubleOrNull() ?: 0.0
    val totalKm = tripN + pickupN
    val perKm = if (totalKm > 0) fareN / totalKm else 0.0
    val fuel = totalKm * fuelN
    val net = fareN - fuel
    val viable = fareN > 0 && totalKm > 0 && perKm >= minN && pickupN <= maxPickupN

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("MotoRent", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text("TU COPILOTO DE GANANCIAS", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            }
            Surface(color = Color(0xFF173A2B), shape = RoundedCornerShape(50)) {
                Text("BETA 0.1", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DocumentScanner, contentDescription = null, tint = Accent)
                    Spacer(Modifier.width(8.dp))
                    Text("Analizar oferta", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Text("Selecciona una captura de pantalla de la oferta de inDrive. MotoRent intentará reconocer el texto; revisa siempre los datos.", color = Muted, fontSize = 12.sp)
                Button(onClick = { picker.launch("image/*") }, enabled = !isReading, modifier = Modifier.fillMaxWidth()) {
                    if (isReading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.ImageSearch, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isReading) "Analizando..." else "Elegir captura")
                }
                Text(status, color = Muted, fontSize = 11.sp)
                if (ocrText != "Aún no has analizado una captura.") {
                    Text("Texto reconocido", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Surface(color = Bg, shape = RoundedCornerShape(10.dp)) {
                        Text(ocrText.take(900), Modifier.padding(10.dp), color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Datos del viaje", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                NumberField("Precio ofrecido (COP)", fare) { fare = it }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumberField("Km del viaje", tripKm, Modifier.weight(1f), true) { tripKm = it }
                    NumberField("Km hasta recoger", pickupKm, Modifier.weight(1f), true) { pickupKm = it }
                }
                Divider(color = Color(0xFF2B3744))
                Text("Tus filtros", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumberField("Mínimo COP/km", minimumPerKm, Modifier.weight(1f), true) { minimumPerKm = it }
                    NumberField("Máx. recogida km", maxPickup, Modifier.weight(1f), true) { maxPickup = it }
                }
                NumberField("Costo estimado de gasolina por km (COP)", fuelCostPerKm) { fuelCostPerKm = it }
                Text("El costo de gasolina es editable y no incluye mantenimiento ni depreciación.", color = Muted, fontSize = 11.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Resultado", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(if (viable) "OFERTA QUE CUMPLE TUS FILTROS" else "NO CUMPLE TUS FILTROS",
                    color = if (viable) Accent else Color(0xFFFFB454), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("Total km", "%.1f km".format(Locale.US, totalKm))
                    Metric("COP por km", money(perKm))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("Gasolina estimada", money(fuel))
                    Metric("Después de gasolina", money(net))
                }
                Text("Es una estimación, no una garantía de ganancia. La decisión de aceptar siempre es tuya.", color = Muted, fontSize = 11.sp)
            }
        }
        Text("MotoRent no se conecta a inDrive ni acepta/rechaza viajes. La lectura OCR de esta versión funciona con capturas elegidas por ti.", color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun NumberField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), decimal: Boolean = false, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { input -> onValue(input.filter { it.isDigit() || (decimal && it == '.') }.take(10)) },
        label = { Text(label, fontSize = 11.sp) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF354454),
            focusedLabelColor = Accent, cursorColor = Accent
        )
    )
}

@Composable
private fun Metric(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

private fun money(value: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("es", "CO"))
    formatter.maximumFractionDigits = 0
    return "$" + formatter.format(value)
}
